let btn = document.querySelector('#btn');
let input = document.querySelector('input[name=github_user]');
let div = document.querySelector('#app');

btn.onclick = function(){
    div.innerHTML = '';

    let ajax = new XMLHttpRequest();

    ajax.open('GET', `https://api.github.com/users/${input.value}`);

    ajax.send(null);

    ajax.onreadystatechange = function(){

        let spanNone = document.createElement('span');

        let txtNome = '';

        if(ajax.readyState === 4){
            if(ajax.status === 200){
                usuario = JSON.parse(ajax.responseText);

                if(usuario['name'] !== null){
                    txtNome = document.createTextNode(usuario['name']);

                    let img = document.createElement('img');
                    img.setAttribute('src', usuario['avatar_url']);
                    img.setAttribute('alt', usuario['name']);
                    img.setAttribute('width', '45px');
                    img.setAttribute('height', '45px');

                    div.appendChild(img);
                }else{
                    txtNome = document.createTextNode(`O usuario ${input.value} Não tem nome`);
                }

                spanNone.appendChild(txtNome);
                div.appendChild(spanNone);

                input.value ='';
            }else{
                txtNome = document.createTextNode(`Não encontrei o usuario ${input.value}`);

                spanNone.appendChild(txtNome);
                div.appendChild(spanNone);

            }
        }
    }
}